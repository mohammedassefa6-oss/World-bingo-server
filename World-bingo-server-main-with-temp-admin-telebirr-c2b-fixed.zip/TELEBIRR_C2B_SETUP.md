# Telebirr C2B WebCheckout setup

This project now includes a C2B WebCheckout adapter based on the `C2B_WebCheckoutDemo` Node.js project downloaded from the Telebirr Developer Portal.

## Railway Variables

Set these in Railway (never commit them):

- `TELEBIRR_FABRIC_APP_ID` = your Fabric App ID
- `TELEBIRR_APP_SECRET` = your App Secret
- `TELEBIRR_MERCHANT_APP_ID` = your Merchant AppId
- `TELEBIRR_MERCHANT_CODE` = the merchant code/ShortCode used by your C2B credentials
- `TELEBIRR_PRIVATE_KEY` = your PrivateKey
- `TELEBIRR_BASE_URL` = `https://developerportal.ethiotelebirr.et:38443/apiaccess/payment/gateway` for sandbox/test
- `TELEBIRR_WEB_BASE_URL` = `https://developerportal.ethiotelebirr.et:38443/payment/web/paygate?` for sandbox/test
- `TELEBIRR_VERIFY_TLS` = `false` only if the Telebirr sandbox certificate prevents Node from connecting; keep `true` for production.
- `TELEBIRR_NOTIFY_URL` = `https://<your-railway-domain>/telebirr/notify`

The code can also derive the notify URL from `PUBLIC_URL` or Railway's `RAILWAY_PUBLIC_DOMAIN`.

## Flow

1. Player enters a deposit amount.
2. `/telebirr/create-order` creates a pending `moneyRequests` record and a Telebirr merchant order.
3. Player is redirected to Telebirr Checkout.
4. Telebirr calls `/telebirr/notify`, and the server re-queries the order before crediting the wallet.
5. The browser return also triggers the same server-side verification.
6. Settlement is idempotent: the same order cannot credit the wallet twice.

The callback itself is **not trusted** for payment success or amount. The server checks Telebirr's order status and compares the confirmed amount with the stored deposit amount before crediting the wallet.

## Important

The existing `DEPOSIT_PHONE`, `DEPOSIT_ACCOUNT_NAME`, `ADMIN_UIDS`, and temporary-admin system are left unchanged. The old manual deposit endpoint remains available as a fallback.
